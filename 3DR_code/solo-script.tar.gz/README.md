# 3DR_code
AUTHOR: Amy Chen (amyjchen@stanford.edu) + edits by Michelle Park
Code written by Amy Chen and Michelle Park (mpark97@stanford.edu)
Requires following the instructions in 
https://dev.3dr.com/starting-network.html and http://www.ddmckinnon.com/2015/12/30/idiots-guide-to-dronekit-python-a-journey-to-whoz-chillin/

# THINGS LEFT TO WORK ON:
- we have not yet run the script on the drone. Primary issue is loading the code
  onto the drone, which requires connecting to both normal wifi and the drone. 
  Stanford wifi complicates this process. Possible solutions are loading the 
  script on another non-Stanford wifi or downloading the needed packages and 
  packing them onto the drone that way.
- MAVLINK allows for setting up geofences which would be much safer. 

# FOLDERS/extra files:
- archive: contains retired code from when we started learning how to program
  with the 3DR SDK
- drone_script: current drone scripts that are up-to-date. files described in 
  the next section.
- future: contains a folder titled "Safety." Unclear who wrote it. Suggests that
  this is how we can implement safety features from the get-go but neither me 
  nor Michelle remember creating it. 
- requirements.txt: file used for packing the script on the drone. Lists 
  packages the drone needs to import via the dual-wifi connection.

# DRONE_SCRIPT:

- dronekit: contains 3DR's SDK. DO NOT DELETE.

- f***.py: Shows a simple takeoff and landing as well as a test for a Keypoller.
  Good reference for future implementations of keypoller as well as gaining 
  understanding of takeoff and landing. 

- keypoller.py & keypoller.pyc & keypollertest.py: keypoller allows for terminal 
 input at any point during the route. Run "python keypollertest.py" to 
 see it in action and to view a simple implementation. keypoller is also used 
 in several scripts.  

- main.py: Program that takes off and asks for user input via KeyPoller for the
  next destination. THIS PROGRAM IS THE CLOSEST WE HAVE TO A FULLY-FUNCTIONAL 
  SEMI-AUTOMATED PATH. Edit GROUNDSPEED variable to set drone's speed (m/s).

- missions: contains coordinates to each point in a route in CSV files. Each 
  file states the total number of points, latitute, longitute, and next possible  
  points for that path. Used in main.py, main_auto.py, and main_guided.py. 
  Locations are destinations on campus.  

- test_takeoff.py: This function does a takeoff of the vehicle and landing. 
  USE THIS TO TEST CODE WHEN FIRST RUNNING AUTONOMOUS ROUTE ON DRONE. The program 
  commands the drone to reach an altitude of 5 meters and immediately land. 

 
